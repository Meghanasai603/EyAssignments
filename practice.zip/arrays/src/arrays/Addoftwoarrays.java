package arrays;
import java.util.*;
public class Addoftwoarrays {

	public static void main(String[] args) {
		int a[]=new int[5];
		int b[]=new int[5];
		int c[]=new int[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			a[i]=sc.nextInt();
			b[i]=sc.nextInt();
			c[i]=a[i]+b[i];
			System.out.println(c[i]+" ");
		}
       
	}

}
