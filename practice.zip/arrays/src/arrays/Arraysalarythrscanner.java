package arrays;
import java.util.Scanner;
public class Arraysalarythrscanner {

	public static void main(String[] args) {
		int salary[] = new int[4];
       Scanner sc=new Scanner(System.in);
       for(int i=0;i<4;i++) {
    	   salary[i]=sc.nextInt();//input to array through scanner class
       }
       for(int k :salary) { //for each loop for printing output from array it is easy to print
    	   System.out.println("salary of person "+ k);
       }
	}

}
