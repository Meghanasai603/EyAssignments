package arrays;
import java.util.Scanner;
public class Findbiggestnuminarr {

	public static void main(String[] args) {
		int a[] = new int[5],big=0; //if we have to print smallest num we have to take big = a[0]
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			a[i]=sc.nextInt();

			if(a[i]>big)                 //a[i]<big
			{
				big=a[i];
			}
		}
		System.out.println("big num in array "+big);
	}

}
