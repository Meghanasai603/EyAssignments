package arrays;
import java.util.*;
public class FindingEvensandOddinarr {

	public static void main(String[] args) {
		int a[]=new int[5];
		int eve=0,odd=0;
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<=4;i++) {
		a[i]=sc.nextInt();
		 if(a[i]%2==0) {
  		   eve++;
  	   }
  	   else {
  		   odd++;
  	   }
		}
       System.out.println("even "+eve+" odd "+odd);
	}

}
