package arrays;
import java.util.Scanner;
public class Findinganelementinarray {
	public static void main(String[] args) {
		int a[]=new int[5];
		int key;
		boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter key value");
		key=sc.nextInt();
		for(int i=0;i<=4;i++) {
			a[i]=sc.nextInt();
		}
		for(int i=0;i<=4;i++) {
			if(a[i]==key) {
				flag=true;
				break;
			}
		}
		if(flag=true) 
			System.out.println("key value found "+key);
		else 
			System.out.println("key element not found");


	}

}
