package arrays;
import java.util.*;
public class Reversingarray {

	public static void main(String[] args) {
		int a[]=new int[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			a[i]=sc.nextInt();
		}
		for(int i=4;i>=0;i--) {
			System.out.print(a[i]+" ");
		}
		
	}

}
