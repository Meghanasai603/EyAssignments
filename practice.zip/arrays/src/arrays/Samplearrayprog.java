package arrays;

public class Samplearrayprog {

	public static void main(String[] args) {
		int marks[]={80,90,100,95};//assigning values at design time
		for(int i=0;i<=3;i++) {
			System.out.println("student marks "+marks[i]);
		}
}
}
