package arrays;
import java.util.*;
public class SortingArray {

	public static void main(String[] args) {
		int a[]=new int[5],t;
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			a[i]=sc.nextInt();
		}
       for(int i=0;i<=4;i++) {
    	   for(int j=i+1;j<=4;j++) {
    		   if(a[i]>a[j]) {
    			   t=a[i];
    			   a[i]=a[j];
    			   a[j]=t;
    		   }
    	   }
       }
       System.out.println("Sorted array... ");
       for(int s:a) {
    	   System.out.println(s+" ");
       }
	}

}
