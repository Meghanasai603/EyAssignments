package arrays;
import java.util.*;
public class StringArray {

	public static void main(String[] args) {
		String cities[]=new String[5];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			cities[i]=sc.nextLine();
		}
		for(String c : cities) {
			System.out.print(c+" ");
		}
	}

}
