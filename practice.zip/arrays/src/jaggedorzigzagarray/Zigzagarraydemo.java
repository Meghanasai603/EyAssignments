package jaggedorzigzagarray;
import java.util.*;
public class Zigzagarraydemo {

	public static void main(String[] args) {
		int a[][]=new int[4][];
		a[0]=new int[3];
		a[1]=new int[2];
		a[2]=new int[5];
		a[3]=new int[1];
//		a[0][0]=10;
//		a[0][1]=11;
//		a[0][2]=12;
//		a[1][0]=13;
//		a[1][1]=14;
//		a[2][0]=15;
//		a[2][1]=16;
//		a[2][2]=17;
//		a[2][3]=17;
//		a[2][4]=18;
//		a[3][0]=19;
      Scanner sc=new Scanner(System.in);
        for(int i=0;i<=3;i++) {
       	for(int j=0;j<=a[i].length-1;j++) {
       		a[i][j]=sc.nextInt();
       	}
       	System.out.println();
        }
        for(int i=0;i<=3;i++) {
        	for(int j=0;j<=a[i].length-1;j++) {
        		System.out.print(a[i][j]+" ");
        	}
        	System.out.println();
        }
	}

}
